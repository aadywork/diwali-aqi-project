# SAMPLE DATA GENERATOR (fake data for practice only)
# Creates data/city_day.csv with the same columns as the Kaggle dataset,
# but the numbers are SIMULATED. Replace the file with the real Kaggle
# city_day.csv to get real results.

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

# city: (normal AQI level, how strongly Diwali raises it)
cities = {
    "Delhi": (190, 1.9), "Lucknow": (170, 1.7), "Patna": (160, 1.6),
    "Kolkata": (120, 1.5), "Chandigarh": (105, 1.5), "Jaipur": (100, 1.45),
    "Ahmedabad": (115, 1.4), "Bhopal": (95, 1.35), "Hyderabad": (90, 1.3),
    "Mumbai": (85, 1.25), "Chennai": (75, 1.2), "Bengaluru": (70, 1.15),
}

diwali_dates = ["2015-11-11", "2016-10-30", "2017-10-19",
                "2018-11-07", "2019-10-27", "2020-11-14"]
diwali_dates = [pd.Timestamp(d) for d in diwali_dates]

def bucket(aqi):
    if aqi <= 50: return "Good"
    if aqi <= 100: return "Satisfactory"
    if aqi <= 200: return "Moderate"
    if aqi <= 300: return "Poor"
    if aqi <= 400: return "Very Poor"
    return "Severe"

rows = []
for city, (base, mult) in cities.items():
    for date in pd.date_range("2015-01-01", "2020-12-31"):
        winter = 1 + 0.4 * np.cos(2 * np.pi * (date.dayofyear - 15) / 365)
        aqi = base * winter * rng.lognormal(0, 0.15)

        # Diwali effect: AQI jumps on Diwali day and the days after
        for d in diwali_dates:
            offset = (date - d).days
            share = {0: 0.6, 1: 1.0, 2: 0.7, 3: 0.3}.get(offset, 0)
            aqi = aqi * (1 + (mult - 1) * share)

        aqi = float(np.clip(aqi, 20, 500))
        pm25 = aqi * 0.55 * rng.lognormal(0, 0.12)
        pm10 = pm25 * 1.7 * rng.lognormal(0, 0.12)
        no2 = 20 + aqi * 0.08 * rng.lognormal(0, 0.2)
        so2 = 8 + aqi * 0.03 * rng.lognormal(0, 0.2)
        co = 0.6 + aqi * 0.004 * rng.lognormal(0, 0.2)
        o3 = 30 + rng.normal(0, 10)

        row = [city, date.strftime("%Y-%m-%d"), pm25, pm10, np.nan, no2,
               np.nan, np.nan, co, so2, o3, np.nan, np.nan, np.nan, aqi, bucket(aqi)]
        # make about 8% of pollutant values missing, like real data
        for i in [2, 3, 5, 8, 9, 10]:
            if rng.random() < 0.08:
                row[i] = np.nan
        # about 3% of AQI values missing
        if rng.random() < 0.03:
            row[14] = np.nan
            row[15] = np.nan
        rows.append(row)

columns = ["City", "Date", "PM2.5", "PM10", "NO", "NO2", "NOx", "NH3", "CO",
           "SO2", "O3", "Benzene", "Toluene", "Xylene", "AQI", "AQI_Bucket"]
pd.DataFrame(rows, columns=columns).round(2).to_csv("data/city_day.csv", index=False)
print("Sample data saved to data/city_day.csv")
